package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private int score;
    private Button 미션;
    TextView scoreView;
    ImageView UserImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        score = 0;
        scoreView = findViewById(R.id.score);

        Button mission1 = findViewById(R.id.미션);
        Button mission2 = findViewById(R.id.미션2);
        UserImg = findViewById(R.id.imageView7);

        mission1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreChange(5);
            }
        });

        mission2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scoreChange(10);
            }
        });
    }


    public void scoreChange(int n) {
        score += n;
        scoreView.setText(String.valueOf(score) + "점");
        if (score >= 100) {
            UserImg.setImageResource(R.drawable.pro);
        }
        if (score >= 200) {
            UserImg.setImageResource(R.drawable.master);
        }
        if (score >= 300) {
            UserImg.setImageResource(R.drawable.champion);
        }
        if (score >= 400) {
            UserImg.setImageResource(R.drawable.grand_champion);

        }

        Intent intent = new Intent(MainActivity.this, SubActivity.class);
        intent.putExtra("score", String.valueOf(score));
        startActivity(intent); // 액티비티 이동

    }
}
